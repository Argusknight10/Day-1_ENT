<?php
session_start();
require 'config.php';

// Cek apakah pengguna adalah admin
if ($_SESSION['role'] !== 'admin') {
    die("Akses ditolak!");
}

// Cek apakah ID berita ada di URL
if (!isset($_GET['id'])) {
    die("ID berita tidak ditemukan!");
}

$id = $_GET['id'];

// Ambil data berita termasuk nama file gambar
$stmt = $pdo->prepare("SELECT image FROM news WHERE id = :id");
$stmt->execute(['id' => $id]);
$newsItem = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$newsItem) {
    die("Berita tidak ditemukan!");
}

// Hapus file gambar jika ada
if (!empty($newsItem['image'])) {
    $imagePath = 'assets/' . $newsItem['image'];
    if (file_exists($imagePath)) {
        unlink($imagePath);  // Hapus file gambar dari server
    }
}

// Hapus berita dari database
$stmt = $pdo->prepare("DELETE FROM news WHERE id = :id");
$stmt->execute(['id' => $id]);

// Redirect kembali ke admin dashboard
header('Location: admin_dashboard.php');
exit;
?>
