<?php
session_start();
require 'config.php';

// Cek apakah pengguna sudah login
$loggedIn = isset($_SESSION['user_id']);

// Ambil semua kategori dari database untuk navbar
$stmt = $pdo->query("SELECT DISTINCT kategori FROM news");
$kategoriList = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Cek jika ada parameter kategori di URL
$kategoriFilter = isset($_GET['kat']) ? $_GET['kat'] : '';

// Ambil berita dari database dengan filter kategori jika ada
$sql = "SELECT * FROM news";
$params = [];

if ($kategoriFilter) {
    $sql .= " WHERE kategori = :kategori";
    $params['kategori'] = $kategoriFilter;
}

$sql .= " ORDER BY created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$newsItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Ambil 3 berita pertama untuk carousel
$carouselItems = array_slice($newsItems, 0, 3);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portal Berita</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand p-3 fs-4" href="index.php">Portal Berita</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ms-auto">
                <?php if ($loggedIn): ?>
                    <?php if ($_SESSION['role'] === 'admin'): ?>
                        <!-- Tampilkan opsi untuk Admin Dashboard jika pengguna adalah admin -->
                        <li class="nav-item">
                            <a class="nav-link fs-5 p-3" href="admin_dashboard.php">Dashboard Admin</a>
                        </li>
                    <?php else: ?>
                        <!-- Tampilkan kategori untuk user biasa -->
                        <?php foreach ($kategoriList as $kategori): ?>
                            <li class="nav-item">
                                <a class="nav-link fs-5 p-3" href="index.php?kat=<?php echo urlencode($kategori); ?>">
                                    <?php echo htmlspecialchars($kategori); ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a class="nav-link fs-5 p-3" href="logout.php">Logout</a>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link fs-5 p-3" href="login.php">Login</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <div class="container mt-4">
        <!-- Carousel -->
        <div id="newsCarousel" class="carousel slide mb-4" data-bs-ride="carousel">
            <div class="carousel-inner">
                <?php foreach ($carouselItems as $index => $item): ?>
                    <div class="carousel-item <?php echo $index === 0 ? 'active' : ''; ?>">
                        <?php if (!empty($item['image'])): ?>
                            <img src="<?php echo htmlspecialchars($item['image']); ?>" class="d-block w-100" style="object-fit: cover; height: 700px;" alt="Gambar Berita">
                        <?php else: ?>
                            <img src="assets/placeholder.jpeg" class="d-block w-100" style="object-fit: cover; height: 700px;" alt="Gambar Berita">
                        <?php endif; ?>
                        <div class="carousel-caption d-none d-md-block">
                            <h5><?php echo htmlspecialchars($item['title']); ?></h5>
                            <p><?php echo htmlspecialchars(substr($item['content'], 0, 100)); ?>...</p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#newsCarousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Sebelumnya</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#newsCarousel" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Selanjutnya</span>
            </button>
        </div>

        <!-- Kartu Berita -->
        <div class="row">
    <?php foreach ($newsItems as $item): ?>
        <div class="col-md-4 mb-3">
            <div class="card">
                <?php if (!empty($item['image'])): ?>
                    <img src="<?php echo htmlspecialchars($item['image']); ?>" class="card-img-top img-fluid" style="object-fit: cover; height: 200px;" alt="Gambar Berita">
                <?php else: ?>
                    <img src="assets/placeholder.jpeg" class="card-img-top img-fluid" style="object-fit: cover; height: 200px;" alt="Gambar Berita">
                <?php endif; ?>
                <div class="card-body">
                    <h5 class="card-title"><?php echo htmlspecialchars($item['title']); ?></h5>
                    <p class="card-text"><?php echo htmlspecialchars(substr($item['content'], 0, 100)); ?>...</p>
                    <a href="<?php echo $loggedIn ? 'view_berita.php?id=' . $item['id'] : 'login.php'; ?>" class="btn btn-primary">
                        Lihat Selengkapnya
                    </a>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>


    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
