-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 29, 2024 at 11:25 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `portal_berita`
--

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `content` text NOT NULL,
  `kategori` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `image`, `content`, `kategori`, `created_at`) VALUES
(1, 'BERITA COVID 19', 'assets/berita1.jpeg', 'covid 19 sempat booming di tahun 2020\r\n', 'kesehatan', '2024-08-29 06:30:45'),
(2, 'BERITA PUTUSAN MK', 'assets/berita2.jpg', 'MK membuat putusan yang tidak disetujui oleh rakyat indonesia', 'politik', '2024-08-29 06:40:14'),
(8, 'CHRIS PUTRA JUARA MR. OLYMPIA', 'assets/chrisputra.jpg', 'juara 2 mr olympia dari indonesia', 'olahraga', '2024-08-29 08:03:56'),
(11, 'ISTANA IKN ', 'assets/66c46a93d9626.jpeg', 'gedung ikn di kalimantan bentuk garuda', 'politik', '2024-08-29 08:30:19');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('user','admin') NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`) VALUES
(1, 'user', '$2y$10$0jA1T4/OGMMtXzfA2GKN6O5RaUzgNMWNHpoWQ/1fD/ucHvvYj7z2y', 'user'),
(7, 'admin', '$2y$10$5haeAG2xXcCsqKoDUPff.OlQCV/jcDjfR79XZAEFF9gSg7bg80K9m', 'admin'),
(8, 'adi ', '$2y$10$.GUzE/IWXyKdJlphUASo.uQace0WVyGYTRMHbZ7zB0pq6PCSWEeIa', 'user'),
(9, 'rafif', '$2y$10$YokJWPblY21f/eNGC9ZaJ.cXCg9dj63EtTWrwRKzZIQOfdQ/FGBu.', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
