<?php
$host = 'localhost';
$dbname = 'portal_berita';
$username = 'root'; // ganti dengan username database Anda
$password = ''; // ganti dengan password database Anda

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Koneksi gagal: " . $e->getMessage());
}

// Simulasi pengecekan apakah pengguna admin
// Ini harus diganti dengan logika yang sesuai dengan implementasi sistem kamu
$isAdmin = isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
?>